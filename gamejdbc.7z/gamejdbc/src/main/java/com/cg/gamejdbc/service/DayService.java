package com.cg.gamejdbc.service;

import java.util.Date;
import java.util.List;

import com.cg.gamejdbc.exceptions.GameException;
import com.cg.gamejdbc.pojo.Day;
import com.cg.gamejdbc.pojo.Game;


public interface DayService {

	public Day addDay(Day day) throws GameException;
	public List<Game> searchByDate(Date date) throws GameException;
}
