package com.cg.gamejpa.dbutil;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class DbUtil 
{
		static EntityManager em=null;
		public static EntityManager getConnection()	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("gameschedular");
		em=emf.createEntityManager();
		EntityTransaction tx=em.getTransaction();
		tx.begin();
		return em;
	}
}
