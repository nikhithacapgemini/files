import {Injectable} from '@angular/core';
import {HttpClient} from'@angular/common/http';
import {Game} from './app.game';
import {throwError,observable} from'rxjs';
import {retry,catchError} from 'rxjs/operators';
@Injectable({
    providedIn:'root'
})
export class GameService{
    constructor(private http:HttpClient){}
    addAllGame(game:any){
          console.log(game);
           let input=new FormData();
           input.append("name",game.name);
           input.append("category",game.category);
           input.append("did",game.did);
           input.append("ddate",game.ddate);
           console.log(input);
           return this.http.post("http://localhost:9098/game/addAll",input);
        }
        searchAllGameName(name:string){
            return this.http.get("http://localhost:9098/game/searchName?name="+name).pipe(catchError(this.handleErrorOne));
        }
        searchAllGameCategory(category:string){
            return this.http.get("http://localhost:9098/game/searchCategory?category="+category).pipe(catchError(this.handleError));
        }
        handleError(error){
            let message="";
            message=`error Code:${error.status}\n Message:${error.message="Game category not found"}`;
            window.alert(message);
            return throwError(message);
        }
         handleErrorOne(error){
            let message="";
            message=`error Code:${error.status}\n Message:${error.message="Game not found"}`;
            window.alert(message);
            return throwError(message);
        }
}