package com.cg.gamee.repository;
import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.gamee.dbutil.DBUtilDay;
import com.cg.gamee.dbutil.DBUtilGame;
import com.cg.gamee.exceptions.GameException;
import com.cg.gamee.pojo.Game;
public class GameRepositoryImplementation implements GameRepository
{
	public List<Game> findByName(String name) throws GameException {
		List<Game> gameSearch=new ArrayList<Game>();
		for (Game game :DBUtilGame.gamesList) { 
			if(game.getName().equals(name)) {
				
				gameSearch.add(game);}
			}
		if(gameSearch.isEmpty())
			throw new GameException("given game not found ");
		return gameSearch;
		}

	public List<Game> findByCategory(String category) throws GameException {
		List<Game> gameSearchOne=new ArrayList<Game>();
		for (Game game : DBUtilGame.gamesList) {
			if(game.getCategory().equals(category)) {
				gameSearchOne.add(game);
				}
			}
		if(gameSearchOne.isEmpty())
			throw new GameException("Given date not found ");
		return gameSearchOne;
	}


	public Game saveGame(Game game) {
		DBUtilGame.gamesList.add(game);
		return game;
	
	}
}
		
		/*	Connection conn=null;
			PreparedStatement pstm=null;
			ResultSet result=null;
			try {
			conn=DBUtilGame.getConnection();
			}catch(GameException e) {
			e.printStackTrace();
			}String query="insert into game(name,category,date) values(?,?,?)";
			try {
			pstm=conn.prepareStatement(query);
			pstm.setString(1, game.getName());
			pstm.setString(2, game.getCategory());
			pstm.setDate(3, (java.sql.Date) game.getDate());
			int res=pstm.executeUpdate();
			}catch(SQLException e) {
			e.printStackTrace();
			}
			finally {
			
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				pstm.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}*/
			

	
	
	/*Day dayData=new Day();
	List<Game> gameData=new ArrayList<Game>();
	public Day save(Day day) {
		
		// TODO Auto-generated method stub
		dayData.getDate();
		dayData.getGame();
		dayData.getGame();
		return day;
		//gameData.add((Game) game);
		dayData.getDate();
		return day;
	}

	public List<Game> findByGameName(String gameName) throws GameException {

		List<Game> daySearch=new ArrayList();
		for (Game game : days) {
			if(game.getGameName().contains(gameName)) {
				daySearch.add(game);
				return daySearch;
			}
		}
		return null;
	}
	public List<Game> findByGameName(String gameName) 
	{
		List<Game> gameNameSearch=new ArrayList();
		for (Game game :gameNameSearch) {
			if(game.getGameName().contains(gameName))
			{
				gameNameSearch.add(game);
			}
		}
		return gameNameSearch;
	}

	public List<Game> findByGameCategory(String gameCategory) {
		// TODO Auto-generated method stub
		return null;
	}
	private List<Game> gameData;
	Day dayData;
	public GameRepositoryImplementation() {
		super();
		gameData=new ArrayList<Game>();
		dayData=new Day();

	}

	public GameRepositoryImplementation(List<Game> gameData) {
		super();
		this.gameData = gameData;
	}

	public boolean saveDay(Day day)
	{
		//dayData.setDate(date);
		return DBUtil.day.add(dayData);
		
	}

	public boolean saveGame(Day day) 
	{
		return DBUtil.games.add(day);
		//gameData.add(game);
		//return game;

}

	public List<Game> findByGameName(String gameName) 
	{
		List<Game> gameNameSearch=new ArrayList();
		for (Game game : gameData) {
			if(game.getGameName().contains(gameName))
			{
				gameNameSearch.add(game);
			}
		}
		return gameNameSearch;
	}
	public List<Game> findByGameCategory(String gameCategory)
	{

		List<Game> gameCategorySearch=new ArrayList();
		for (Game game : gameData) {
			if(game.getCategoryName().contains(gameCategory))
			{
				gameCategorySearch.add(game);
			}
		}
		return gameCategorySearch;
	}

	public boolean save(Day day) {
		// TODO Auto-generated method stub
		return false;
	}

		*/

