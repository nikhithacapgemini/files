package com.cg.gamejpa.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.gamejpa.dbutil.DbUtil;
import com.cg.gamejpa.exceptions.GameException;
import com.cg.gamejpa.pojo.Day;
import com.cg.gamejpa.pojo.Game;

public class DayrepositoryImplementation implements DayRepository {
	EntityManager em;
	public DayrepositoryImplementation() 
	{
		//em=DbUtil.getConnection();
	}

	public Day save(Day day) {
		try {
		em=DbUtil.getConnection();
		em.merge(day);
		em.getTransaction().commit();
		return day;
		}
		finally {
			if(em!=null)
				em.close();
		}
	}

	public List<Game> findByDate(Date date) throws GameException {
		try {
		em=DbUtil.getConnection();
		List<Game> gameList=null;
		Query query=em.createQuery("select g from Day d join d.game g where d.date=:date");
 		query.setParameter("date",date);
		gameList=query.getResultList();
		//System.out.println(gameList);
		return gameList;
		}
		catch(Exception e) {
			throw new GameException("Date not found");
		}
		finally {
			if(em!=null)
				em.close();
		}
	}

}
