package com.cg.gamejpa.pojo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Game 
{
	@Id
	private String name;
	private String category;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="game")
	List<Day> days;
	
	public List<Day> getDays() {
		return days;
	}
	public void setDays(List<Day> days) {
		this.days = days;
	}
	public Game() {
	}
	public Game(String name, String category, List<Day> days) {
		super();
		this.name = name;
		this.category = category;
		this.days = days;
	}
	/*public Game( String name, String category) {
		this.name = name;
		this.category = category;	
	}*/
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "Game [name=" + name + ", category=" + category + "]";
	}
	
	
	
}
