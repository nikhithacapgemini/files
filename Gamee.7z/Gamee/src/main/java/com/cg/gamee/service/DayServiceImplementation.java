package com.cg.gamee.service;

import java.util.Date;
import java.util.List;

import com.cg.gamee.exceptions.GameException;
import com.cg.gamee.pojo.Day;
import com.cg.gamee.pojo.Game;
import com.cg.gamee.repository.DayRepository;
import com.cg.gamee.repository.DayRepositoryImplementation;

public class DayServiceImplementation implements DayService
{
	DayRepository repositoryDay;
	public DayServiceImplementation() {
		repositoryDay=new DayRepositoryImplementation();
	}
	public Day addDay(Day day) {
		repositoryDay.save(day);
		return day;
	}
	public List<Day> searchByDate(Date date) throws GameException{
		return repositoryDay.findByDate(date);
	}
	
	
}
