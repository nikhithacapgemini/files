package com.cg.gamespringcore.repository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.cg.gamespringcore.dbutil.DBUtilGame;
import com.cg.gamespringcore.exceptions.GameException;
import com.cg.gamespringcore.pojo.Game;
@Repository("gameRepository")
public class GameRepositoryImplementation implements GameRepository
{
	/**Written by Nikhitha on 14-05-2019
	   Last modified on 14-05-2019
	   The Method  findByName() is used to find the game details using game name*/
	public List<Game> findByName(String name) {
		List<Game> gameSearch=new ArrayList<Game>();
		for (Game game :DBUtilGame.gamesList) { 
			if(game.getName().equals(name)) {
				gameSearch.add(game);
				}	
			}
		return gameSearch;
		}

	/**Written by Nikhitha on 14-05-2019
	   Last modified on 14-05-2019
	   The Method  findByCategory() is used to find the game details using game category
	 **/
	public List<Game> findByCategory(String category) {
		List<Game> gameSearchOne=new ArrayList<Game>();
		for (Game game : DBUtilGame.gamesList) {
			if(game.getCategory().equals(category)) {
				gameSearchOne.add(game);
				//return gameSearchOne;
				}
			}

		return  gameSearchOne;
	}
	/**Written by Nikhitha on 14-05-2019
	   Last modified on 14-05-2019
	   The Method saveGame() is used to save the game by entering game name ,game category*/
	public Game saveGame(Game game)  {
		/*DBUtilGame.gamesList.add(game);
		return game;*/
		for(Game g:DBUtilGame.gamesList) {
			if(g.getName().contains(game.getName()))
				return null;
				break;
			}
			DBUtilGame.gamesList.add(game);
			return game;
		}
	
	}

		