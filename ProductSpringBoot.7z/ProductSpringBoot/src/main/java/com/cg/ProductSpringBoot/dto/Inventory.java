package com.cg.ProductSpringBoot.dto;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Inventory {
	@Id
	@Column(name="i_id")
	private int id;
	@Column(name="i_name")
	private String name;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="prod_id")
	private Product product;
	public Inventory() {
		
	}
	public Inventory(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public Inventory(int id, String name, Product product) {
		super();
		this.id = id;
		this.name = name;
		this.product = product;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	@Override
	public String toString() {
		return "Inventory [id=" + id + ", name=" + name + "]";
	}
	
	
}
