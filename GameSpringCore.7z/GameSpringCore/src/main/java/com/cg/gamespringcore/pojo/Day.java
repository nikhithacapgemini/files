package com.cg.gamespringcore.pojo;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Component("day")
@Scope(value="prototype")
/**Written by Nikhitha on 14-05-2019
Last modified on 16-05-2019
The class Day is used to declare the what kind of variables we are using for that variables generating getters&setters and constructors ,toString */
public class Day 
{
	private Date date;
	private List<Game> games;
	public List<Game> getGames() {
		return games;
	}
	public void setGames(List<Game> games) {
		this.games = games;
	}
	public  Day() {
		
	}
	
	public Day(Date date, List<Game> games) {
		super();
		this.date = date;
		this.games = games;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Day [date=" + date + ", games=" + games + "]";
	}
	
}