package com.cg.gamee.service;

import java.util.Date;
import java.util.List;

import com.cg.gamee.exceptions.GameException;
import com.cg.gamee.pojo.Day;
import com.cg.gamee.pojo.Game;

public interface GameService 
{
	
	public Game addGame(Game game);
	public List<Game> searchByName(String name) throws GameException;
	public List<Game> searchByCategory(String category) throws GameException;
	
	
	
}
