package com.cg.gamejdbc.repository;

import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.gamejdbc.dbutil.DBUtil;
import com.cg.gamejdbc.exceptions.GameException;
import com.cg.gamejdbc.pojo.Day;
import com.cg.gamejdbc.pojo.Game;

public class GameRepositoryImplementation implements GameRepository{

	//finding the game details using game name
	public List<Game> findByName(String name) throws GameException {
		Connection conn=null;
		PreparedStatement pstm=null;
		ResultSet result=null;
		List<Game> gameSearch=null;
		conn=DBUtil.getConnection();
		try {
				pstm=conn.prepareStatement("select g.name,g.category,d.date from game g inner join day d on g.name=d.gname where name=?");
				gameSearch=new ArrayList<Game>();
				pstm.setString(1,name);
				result = pstm.executeQuery();
				while(result.next()) 
				{

					Game game=new Game();
					Day day=new Day();
					game.setName(result.getString(1));
					game.setCategory(result.getString(2));
					day.setDate(result.getDate(3));
					gameSearch.add(game);
					System.out.println(day.getDate());
					System.out.println(game);
			
				} 
			}
			catch (SQLException e)
			{
				System.out.println("given name not found");
			}
		finally {
			try {
					conn.close();
					pstm.close();
				} 
		catch (SQLException e) 
		{
			throw new GameException("close the connections");
		}}
			if(gameSearch.isEmpty())
				throw new GameException("Given game name not found ");
		return gameSearch;
		}
	//finding the game details using game category
	public List<Game> findByCategory(String category) throws GameException 
	{
		PreparedStatement pstm=null;
		ResultSet result=null;
		Connection conn=null;
		conn=DBUtil.getConnection();
		List<Game> gameSearch=new ArrayList<Game>();
		try {
		pstm=conn.prepareStatement("select d.gname,g.category,d.date from game g right outer join day d on g.name=d.gname where g.category=?");
		pstm.setString(1,category);
		result = pstm.executeQuery();
		while(result.next()) 
		{	
			Game game=new Game();
			Day day=new Day();
			game.setName(result.getString(1));
			game.setCategory(result.getString(2));
			day.setDate(result.getDate(3));
			gameSearch.add(game);
			System.out.println(day.getDate());
			System.out.println(game);

		} 
		}
		catch (SQLException e)
		{
				e.printStackTrace();
		}
		finally {
			try {
				conn.close();
				pstm.close();
			} 
		catch (SQLException e) 
		{
			throw new GameException("close the connections");
		}}
		if(gameSearch.isEmpty())
			throw new GameException(" category not found ");
			return gameSearch;
		}
	
		//saving the game details
		public Game saveGame(Game game) throws GameException
		{
			PreparedStatement pstm=null;
			ResultSet result=null;
			Connection conn=null;
			try {
					conn=DBUtil.getConnection();
					String query="insert into game(name,category) values(?,?)";
					pstm=conn.prepareStatement(query);
					pstm.setString(1, game.getName());
					pstm.setString(2, game.getCategory());
					int res=pstm.executeUpdate();
					if(res>0) {
						System.out.println("data entered");
					}
			}
			finally {
				try {
					conn.close();
					pstm.close();
				} 
			catch (SQLException e) 
			{
				throw new GameException("close all the connections");
			}
			return game;

		}}}
		
