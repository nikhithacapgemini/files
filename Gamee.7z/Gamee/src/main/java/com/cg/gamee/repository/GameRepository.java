package com.cg.gamee.repository;

import java.util.Date;
import java.util.List;

import com.cg.gamee.exceptions.GameException;
import com.cg.gamee.pojo.Day;
import com.cg.gamee.pojo.Game;
public interface GameRepository
{
	public List<Game> findByName(String Name) throws GameException;
	public List<Game> findByCategory(String Category) throws GameException;
	public Game saveGame(Game game);
	
	
}
