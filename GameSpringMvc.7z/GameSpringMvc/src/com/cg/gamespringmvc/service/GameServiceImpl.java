package com.cg.gamespringmvc.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.gamespringmvc.exception.GameException;
import com.cg.gamespringmvc.pojo.Day;
import com.cg.gamespringmvc.pojo.Game;
import com.cg.gamespringmvc.repository.GameRepository;
@Service
@Transactional
public class GameServiceImpl implements GameService{
	@Autowired
	GameRepository gameRepository;
	//--------------------------------------------------------------//
	/** @Author Nikhitha
	 * Written on21-05-2019
	 * last Modified 22-05-2019
	 * @return game 
	 * It will add data and return game **/
	@Override
	public Game addGame(Game game) {
		// TODO Auto-generated method stub
		return gameRepository.saveGame(game);
	}
	//-------------------------------------------------------------//
	/** @Author Nikhitha
	 * Written on21-05-2019
	 * last Modified 22-05-2019
	 * @return List<Game> 
	 * It will find  data by using game name **/
	@Override
	public List<Game> searchByName(String name) throws GameException {
		// TODO Auto-generated method stub
		List<Game> listSearch=null;
		
			listSearch = gameRepository.findByName(name);
			return listSearch;	
	
	}
	
	//------------------------------------------------------------------//
	/** @Author Nikhitha
	 * Written on21-05-2019
	 * last Modified 22-05-2019
	 * @return List<Game> 
	 * It will find  data by using game category **/
	@Override
	public List<Game> searchByCategory(String category) {
		// TODO Auto-generated method stub
		List<Game> listSearch=gameRepository.findByCategory(category);
		return listSearch;
	}
	

}
