package com.cg.ProductSpringBoot.dto;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity
public class Product implements Serializable {
	@Id
	private int id;
	private String name;
	private double price;
	private String description;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="product")
	//@JoinColumn(name="prod_inventory")
	private List<Inventory> inventory;
	public Product() {
		
	}
	
	public Product(int id, String name, double price, String description, List<Inventory> inventory) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.description = description;
		this.inventory = inventory;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public List<Inventory> getInventory() {
		return inventory;
	}
	public void setInventory(List<Inventory> inventory) {
		this.inventory = inventory;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", description=" + description
				+ ", inventory=" + inventory + "]";
	}
	
	
}
