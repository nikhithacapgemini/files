package com.cg.gamespringmvc.repository;

import java.util.Date;
import java.util.List;

import com.cg.gamespringmvc.pojo.Day;
import com.cg.gamespringmvc.pojo.Game;

public interface DayRepository {
	public Day save(Day day);
	public List<Game> findByDate(Date date);
}
