package com.cg.gamespringcore.dbutil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.gamespringcore.pojo.Day;
import com.cg.gamespringcore.pojo.Game;

public class DBUtilDay 
{
	public static List<Day> daysList=new ArrayList<Day>();

}
