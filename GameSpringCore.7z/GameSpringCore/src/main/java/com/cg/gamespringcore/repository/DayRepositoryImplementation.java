package com.cg.gamespringcore.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.gamespringcore.dbutil.DBUtilDay;
import com.cg.gamespringcore.dbutil.DBUtilGame;
import com.cg.gamespringcore.exceptions.GameException;
import com.cg.gamespringcore.pojo.Day;
import com.cg.gamespringcore.pojo.Game;
@Repository("dayRepository")
public class DayRepositoryImplementation implements DayRepository
{
	/**Written by Nikhitha on 14-05-2019
	   Last modified on 14-05-2019
	   The Method  save() is used to save the game to particular date*/
	public boolean save(Day day) {
		 DBUtilDay.daysList.add(day);
		 return true;
	}
	/**Written by Nikhitha on 14-05-2019
	   Last modified on 14-05-2019
	   The Method  findByDate() is used to find the game details using date*/
	public List<Game> findByDate(Date date)  {
		List<Game> listbyGame=new ArrayList<Game>();
		/*List<Day> dayList=null;
		dayList=DBUtilDay.daysList;
		System.out.println(dayList);*/
		/*for (Game game :DBUtilGame.gamesList ) {
//			System.out.println(DBUtilDay.daysList);
		if(dayList.equals(date)) { 
			listbyGame.add(game);
			return listbyGame;

		}
		}*/
		System.out.println(DBUtilDay.daysList);
		for(Day g: DBUtilDay.daysList)
			if(g.getDate().equals(date)) 
			{
				listbyGame=g.getGames();
//				listbyGame.addAll(g.getGames());		
			}
	
		return listbyGame;
		
	}
}

	
	
	
	
