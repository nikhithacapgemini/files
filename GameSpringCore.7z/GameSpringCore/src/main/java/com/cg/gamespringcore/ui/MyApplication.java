package com.cg.gamespringcore.ui;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;
import com.cg.gamespringcore.config.JavaConfig;
import com.cg.gamespringcore.dbutil.DBUtilDay;
import com.cg.gamespringcore.exceptions.GameException;
import com.cg.gamespringcore.pojo.Day;
import com.cg.gamespringcore.pojo.Game;
import com.cg.gamespringcore.service.DayService;
import com.cg.gamespringcore.service.GameService;

@Component
public class MyApplication
{	
	static GameService gameService1;
	static DayService dayService1;
	@Autowired
	GameService gameService;
	@Autowired
	DayService dayService;
	@PostConstruct
	public void init() {
		gameService1 = this.gameService;
		dayService1 = this.dayService;
	   }
	
	public static void main(String[] args) throws GameException 
	{
		AnnotationConfigApplicationContext app=new AnnotationConfigApplicationContext(JavaConfig.class);
		//	Game game=(Game) app.getBean("game");
		Day day=null;
		Scanner scr=new Scanner(System.in);
		int choice=0;
		do {
			printDetails();
			System.out.println("Enter your choice");
			choice=scr.nextInt();
			switch(choice){
			/**adding the game**/
			case 1:	
				try {
				Game game=(Game) app.getBean("game");				
				System.out.println("Enter name of the game");
				String gameName=scr.next();
				System.out.println("enter game category indoor/outdoor");
				String gameCategory=scr.next();
				game.setName(gameName);
				game.setCategory(gameCategory);
				gameService1.addGame(game);
				System.out.println(game);
				System.out.println("data added");}
				catch(GameException e) {
					System.out.println(e.getMessage());
				}
				
			
			break;
			/**adding the date to the particular game**/
			case 2: day=(Day) app.getBean("day");
				System.out.println("enter the date");
				String addDate1=scr.next();
				SimpleDateFormat sdf3 = new SimpleDateFormat("dd-MM-yyyy");
				Date date4=null;
				try {
					date4 =  sdf3.parse(addDate1);
				} 
				catch (Exception e)
				{
					System.out.println("Date " +  addDate1+ " is not valid according to " +((SimpleDateFormat) sdf3).toPattern() + " pattern.");
					break;
				}
				System.out.println("enter the name");
				String gname=scr.next();
				try {
						List<Game> games1=gameService1.searchByName(gname);
						List<Day> daysList=new ArrayList<Day>();
						day.setDate(date4);
						day.setGames(games1);
						daysList.add(day);
						dayService1.addDay(day);
						//System.out.println(daysList);
						System.out.println(DBUtilDay.daysList);
						System.out.println("game is added to date");
					}
				catch(GameException e) {
					System.err.println(e.getMessage());
				}
				break;
				/** searching the game details using game name**/
				case 3:System.out.println("Enter the game name to search");
				String gameNameToSearch=scr.next();
				List<Game> gameSearch=null;
				try {
					gameSearch=gameService1.searchByName(gameNameToSearch);
					for (Game game2 : gameSearch) {
						System.out.println("game name : "+game2.getName() );
						System.out.println("game category : "+game2.getCategory());

					}
				}
				catch(GameException e) {
				System.err.println(e.getMessage());
				}
				break;
				/**searching the game details using game category i.e.., indoor/outdoor**/
				case 4:	System.out.println("Enter the category name to search ");
				String gameCategoryToSearch=scr.next();
				List<Game> gameSearchTwo=null;
				try {
					gameSearchTwo=gameService1.searchByCategory(gameCategoryToSearch);
					if(gameSearchTwo!=null) {
						for (Game game2 : gameSearchTwo) {
					System.out.println("game name : "+game2.getName() );
					System.out.println("game category : "+game2.getCategory());
						}
					}
				}
				catch(GameException e) {
				System.out.println(e.getMessage());
				}
				break;
				/**searching the game details using date**/
				case 5: 
					System.out.println("enter the date");
					String searchDate=scr.next();
					SimpleDateFormat sdf4 = new SimpleDateFormat("dd-MM-yyyy");
					Date date5=null;
					try {
						date5 =  sdf4.parse(searchDate);
					} 
					catch (Exception e1) {
						System.out.println("Date " +  searchDate+ " is not valid according to " +
								((SimpleDateFormat) sdf4).toPattern() + " pattern.");
						break;
					}
					try {
						List<Game> listSearch=dayService1.searchByDate(date5);
						System.out.println(listSearch);
						for (Game game2 : listSearch) {
							System.out.println("game name : "+game2.getName());
							System.out.println(" category :"+game2.getCategory());
						}}
					catch(GameException e) {
						System.err.println(e.getMessage());		
					}
					break;	
				default:System.err.println("Invalid choice");
				break;
				}
			
				}while(choice!=6);
			scr.close();
		}
	public static void printDetails()
	{

		System.out.println("1.Adding game  ");
		System.out.println("2.Adding date ");
		System.out.println("3.Search by game name");
		System.out.println("4.Search by category game : indoor/outdoor");
		//System.out.println("5.Search by date");



	}

}
