package com.cg.gamespringcore.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.cg.gamespringcore")
/**Written by Nikhitha on 14-05-2019
Last modified on 14-05-2019
The class JavaConfig is used to */
public class JavaConfig {

}
