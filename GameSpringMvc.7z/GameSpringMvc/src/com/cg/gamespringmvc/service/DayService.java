package com.cg.gamespringmvc.service;

import java.util.Date;
import java.util.List;

import com.cg.gamespringmvc.pojo.Day;
import com.cg.gamespringmvc.pojo.Game;
public interface DayService {
	public Day addDay(Day day) ;
	public List<Game> searchByDate(Date date);
}
