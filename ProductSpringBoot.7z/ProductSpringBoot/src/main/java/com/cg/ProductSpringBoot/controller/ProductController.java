package com.cg.ProductSpringBoot.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ProductSpringBoot.dto.Inventory;
import com.cg.ProductSpringBoot.dto.Product;
import com.cg.ProductSpringBoot.services.ProductService;

import ch.qos.logback.core.net.SyslogOutputStream;

@RestController
@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductService productService;
	/*@RequestMapping(method=RequestMethod.GET,value="/checkname/{uname}")
	
	public String getName(@PathVariable("uname") String mname,@RequestParam("prodid") String id) {
		return id+"   Capgemini  "+mname;
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/checkname")
	public String getData(@RequestParam("prodid")String pid,@RequestParam("prodName")String pname,@RequestParam("prodprice")String pprice) {
		System.out.println(pid+" "+pname+" "+pprice);
		return "welcome";
	}*/
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ResponseEntity<Product> addProduct(@RequestBody Product pro) {
		Product prod=productService.addProduct(pro);
		if(prod==null) {
		return new ResponseEntity("Product not found",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(prod,HttpStatus.OK);
	}
	@RequestMapping(value="/show",method=RequestMethod.GET)
	public ResponseEntity<List<Product>> showAllProduct(){
		List<Product> myList=productService.showAll();
		if(myList.isEmpty()) {
			return new ResponseEntity("No product to show",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
		
	}
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public ResponseEntity<List<Product>> searchProduct(@RequestParam("name")String name) {
		
		List<Product> myList=productService.searchByName(name);
		if(myList.isEmpty()) {
			return new ResponseEntity("No product found with this name "+name,HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
		
	}
	@RequestMapping(value="/searchprice",method=RequestMethod.POST)
	public ResponseEntity<List<Product>> searchProductPrice(@RequestParam("min")Double min,@RequestParam("max")Double max) {
		
		List<Product> myList=productService.searchByPrice(min, max);
		if(myList.isEmpty()) {
			return new ResponseEntity("No product found with this range ",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(myList,HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/addall",method=RequestMethod.POST)
	public ResponseEntity<Product> addAll(@ModelAttribute Product prod){
		//Inventory inventory=new Inventory();
		//Product prod=new Product();
		/*inventory.setId(inid);
		inventory.setName(inname);
		
		Product prod=new Product();
		prod.setId(id);
		prod.setName(name);
		prod.setPrice(price);
		prod.setDescription(desc);
		prod.setInventory(inventory);
		*/
		//prod.setInventory(inventory);
		Product pro=productService.addProduct(prod);
		if(pro==null) {
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(pro,HttpStatus.OK);
		
		
	}
	/*@RequestMapping(value="/addall",method=RequestMethod.POST)
	public ResponseEntity<Product> addAll(@RequestParam("id") int id,
										@RequestParam("name") String name,
										@RequestParam("price") double price,
										@RequestParam("desc") String desc,
										@RequestParam("inid") int inid,
										@RequestParam("inname") String inname){
		Inventory inventory=new Inventory();
		inventory.setId(inid);
		inventory.setName(inname);
		
		Product prod=new Product();
		prod.setId(id);
		prod.setName(name);
		prod.setPrice(price);
		prod.setDescription(desc);
		prod.setInventory(inventory);
		
		Product pro=productService.addProduct(prod);
		if(pro==null) {
			return new ResponseEntity(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(HttpStatus.OK);
		
		
	}*/
										
										
	
	
	
	
	
	
	
	
	/*@RequestMapping(value="/delete",method=RequestMethod.DELETE)
	public void deleteProduct(@RequestParam("id") int id) {
		productService.deleteById(id);;
	}
	@RequestMapping(value="/update",method=RequestMethod.PUT)
	public Product updateProduct(@RequestBody Product product ) {
		return productService.updateById(product);
		
	}
	@RequestMapping(value="/searchN",method=RequestMethod.GET)
	public List<Product> search(@RequestParam("pname")String pname){
		System.out.println(pname);
		return productService.searchByName(pname);
	}*/

}/*/nikhitha?prodid=100*/
