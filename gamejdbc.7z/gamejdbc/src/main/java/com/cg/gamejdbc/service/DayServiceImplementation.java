package com.cg.gamejdbc.service;

import java.util.Date;
import java.util.List;

import com.cg.gamejdbc.exceptions.GameException;
import com.cg.gamejdbc.pojo.Day;
import com.cg.gamejdbc.pojo.Game;
import com.cg.gamejdbc.repository.DayRepository;
import com.cg.gamejdbc.repository.DayRepositoryImplementation;


public class DayServiceImplementation implements DayService{
	DayRepository repositoryDay;
	public DayServiceImplementation() {
		repositoryDay=new DayRepositoryImplementation();
	}
	public Day addDay(Day day) throws GameException {
		repositoryDay.save(day);
		return day;
	}
	public List <Game> searchByDate(Date date) throws GameException{
		return repositoryDay.findByDate(date);
	}
	

}
