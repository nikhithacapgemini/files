package com.cg.gamejdbc.exceptions;

public class GameException extends Exception {

	public GameException(String string) {
		super(string);
	}
}
