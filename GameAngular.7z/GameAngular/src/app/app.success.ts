import {Component} from '@angular/core';
@Component({
    selector:'cap',
     templateUrl: 'app.addsuccess.html'
})

export class Success { 
    
}