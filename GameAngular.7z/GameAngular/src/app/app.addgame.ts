import {Component} from '@angular/core';
import {Game} from './app.game';
import {GameService} from './app.gameservice';
import {Router} from '@angular/router';

@Component({
    selector:'add-game',
    templateUrl:'app.addgame.html',
})

export class AddGame{
    constructor(private gameservice:GameService,private router:Router){
    }
    games:Game[];
    model:any={};
    name:string;
    category:string;
    did:number;
    ddate:Date;
    addGame(){  
        //console.log(this.model);
        this.gameservice.addAllGame(this.model).subscribe((data:any)=>console.log(data));
        this.router.navigateByUrl("addingsuccess");
     
    }
}