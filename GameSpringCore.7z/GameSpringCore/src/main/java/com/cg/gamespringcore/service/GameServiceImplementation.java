package com.cg.gamespringcore.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.gamespringcore.exceptions.GameException;
import com.cg.gamespringcore.pojo.Day;
import com.cg.gamespringcore.pojo.Game;
import com.cg.gamespringcore.repository.GameRepository;
import com.cg.gamespringcore.repository.GameRepositoryImplementation;
@Repository("gameService")
public class GameServiceImplementation implements GameService
{
	@Autowired
	GameRepository gameRepository;
	public GameServiceImplementation() {
		}
	/**Written by Nikhitha on 14-05-2019
	   Last modified on 14-05-2019
	   The Method addGame() is used to adding the game by entering game name ,game category*/
	public Game addGame(Game game) throws GameException {
		Game games=gameRepository.saveGame(game);
		if(games==null) {
			throw new GameException("game already exist");
		}
		return game;
	}
	/**Written by Nikhitha on 14-05-2019
	   Last modified on 14-05-2019
	   The Method  searchByName() is used to search the game details using game name*/
	public List<Game> searchByName(String name) throws GameException {
		List<Game> listSearch=gameRepository.findByName(name);
		if(listSearch.isEmpty()||listSearch==null)
			throw new GameException("Game name not found");
		return listSearch;
		
	}
	/**Written by Nikhitha on 14-05-2019
	   Last modified on 14-05-2019
	   The Method  searchByCategory() is used to search the game details using game category*/
	public List<Game> searchByCategory(String category) throws GameException {
		List<Game> listSearch=gameRepository.findByCategory(category);
		if(listSearch.isEmpty())
			throw new GameException("category not found");
		return listSearch;
	}
	
}