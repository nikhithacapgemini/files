package com.cg.gamee.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.gamee.dbutil.DBUtilDay;
import com.cg.gamee.dbutil.DBUtilGame;
import com.cg.gamee.exceptions.GameException;
import com.cg.gamee.pojo.Day;
import com.cg.gamee.pojo.Game;

public class DayRepositoryImplementation implements DayRepository
{
	
	public boolean save(Day day) {
		 DBUtilDay.daysList.add(day);
		 return true;
	}
	public List<Day> findByDate(Date date) throws GameException {
		List<Day> listbyDay=new ArrayList<Day>();
		for (Day day1 : DBUtilDay.daysList)
		{ 
//			System.out.println(day1.getDate());
			if(day1.getDate().equals(date))
			{
				listbyDay.add(day1);
				//if(DBUtilGame.gamesList.contains(day1)==(DBUtilDay.daysList.contains(date))) {
				//if(DBUtilGame.gamesList.equals(date)==DBUtilDay.daysList.contains(date))
				//if(DBUtilGame.gamesList.contains(DBUtilDay.daysList.))
				//if(DBUtilDay.daysList.contains(DBUtilGame.gamesList.get(2))) {
				//System.out.println(DBUtilGame.gamesList);}
				
			}
		}
				//return listbyDay;
	if(listbyDay.isEmpty())
		throw new GameException("Given date not found ");
	return listbyDay;
}
}