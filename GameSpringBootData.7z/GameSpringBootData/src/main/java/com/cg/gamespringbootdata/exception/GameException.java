package com.cg.gamespringbootdata.exception;

public class GameException extends Exception{
	public GameException() {
		super();
	}
	public GameException(String s) {
		super(s);
	}
}
