package com.cg.gamejdbc.service;

import java.util.List;

import com.cg.gamejdbc.exceptions.GameException;
import com.cg.gamejdbc.pojo.Game;

public interface GameService {

	public Game addGame(Game game) throws GameException;
	public List<Game> searchByName(String name) throws GameException;
	public List<Game> searchByCategory(String category) throws GameException;
	

}
