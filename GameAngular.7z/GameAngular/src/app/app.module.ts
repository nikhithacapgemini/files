﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {FormsModule} from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';
import {AddGame}  from './app.addgame';
import {SearchGameName }  from './app.searchgamename';
import {SearchGameCategory}  from './app.searchgamecategory';
import {HttpClientModule} from'@angular/common/http';
import {NgxPaginationModule}  from 'ngx-pagination'
import {Success} from './app.success';

const route:Routes=[
    {path:'addingsuccess',component:Success},
    {path:'addgame',component:AddGame},
    {path:'searchname',component:SearchGameName},
    {path:'searchcategory',component:SearchGameCategory},
];  
@NgModule({
    imports: [
        BrowserModule,FormsModule,RouterModule.forRoot(route),HttpClientModule,NgxPaginationModule
        
    ],
    declarations: [
        AppComponent,AddGame,SearchGameName,SearchGameCategory,Success
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }