package com.cg.gamee.service;

import java.util.Date;
import java.util.List;

import com.cg.gamee.exceptions.GameException;
import com.cg.gamee.pojo.Day;
import com.cg.gamee.pojo.Game;

public interface DayService 
{
	public Day addDay(Day day);
	public List< Day >searchByDate(Date date) throws GameException;

}
