package com.cg.gamee.dbutil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.gamee.pojo.Day;
import com.cg.gamee.pojo.Game;

public class DBUtilDay 
{
	public static List<Day> daysList=new ArrayList<Day>();
	
	//static  Date date=new Date();
	//static  Date dateOne=new Date();
	//Day day=new Day(date,DBUtilGame.gamesList);
	
	/*static {
		Day dayTwo=new Day(date,DBUtilGame.gamesList);
		//Day dayThree=new Day(dateOne,DBUtilGame.gamesList);
		daysList.add(dayTwo);
		//daysList.add(dayThree);
	}
*/
	
}
