package com.cg.gamespringcore.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.gamespringcore.exceptions.GameException;
import com.cg.gamespringcore.pojo.Day;
import com.cg.gamespringcore.pojo.Game;
import com.cg.gamespringcore.repository.DayRepository;
import com.cg.gamespringcore.repository.DayRepositoryImplementation;
@Service("dayService")
public class DayServiceImplementation implements DayService
{
	@Autowired
	DayRepository dayRepository;
	public DayServiceImplementation() {
		
	}
	/**Written by Nikhitha on 14-05-2019
	   Last modified on 14-05-2019
	   The Method  addDay() is used to adding the date to particular game*/

	public Day addDay(Day day) {
		dayRepository.save(day);
		return day;
	}
	/**Written by Nikhitha on 14-05-2019
	   Last modified on 14-05-2019
	   The Method  searchByDate() is used to find the game details using date*/
	public List<Game> searchByDate(Date date) throws GameException{
		List<Game> listSearch=dayRepository.findByDate(date);
		if(listSearch==null)
			throw new GameException("date not found");
		return listSearch;
	}
	
	
}
