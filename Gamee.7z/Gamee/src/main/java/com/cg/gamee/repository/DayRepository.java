package com.cg.gamee.repository;

import java.util.Date;
import java.util.List;

import com.cg.gamee.exceptions.GameException;
import com.cg.gamee.pojo.Day;
import com.cg.gamee.pojo.Game;

public interface DayRepository 
{
	public boolean save(Day day);
	public List<Day> findByDate(Date date) throws GameException;
}
