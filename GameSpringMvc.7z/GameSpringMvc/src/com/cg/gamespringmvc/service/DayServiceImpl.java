package com.cg.gamespringmvc.service;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.gamespringmvc.pojo.Day;
import com.cg.gamespringmvc.pojo.Game;
import com.cg.gamespringmvc.repository.DayRepository;
//@Service
//@Transactional
public class DayServiceImpl {
	/*@Autowired
	DayRepository dayRepository;
	@Override
	public Day addDay(Day day) {
		// TODO Auto-generated method stub
		return dayRepository.save(day);
	}

	@Override
	public List<Game> searchByDate(Date date) {
		// TODO Auto-generated method stub
		return null;
	}
*/
}
