package com.cg.gamee.dbutil;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.cg.gamee.exceptions.GameException;
import com.cg.gamee.pojo.Game;
public class DBUtilGame {
	
	public static List<Game> gamesList=new ArrayList<Game>();
	/*static Connection conn;
	public static Connection getConnection() throws GameException {
	Properties prop=new Properties();
	try {
	InputStream it=new FileInputStream("resource/jdbc.properties");
	prop.load(it);
	if(prop!=null) {
	String driver=prop.getProperty("jdbc.driver");
	String url=prop.getProperty("jdbc.url");
	String uname=prop.getProperty("jdbc.username");
	String upass=prop.getProperty("jdbc.password");
	Class.forName(driver);
	conn=DriverManager.getConnection(url,uname,upass);
	}
	}
	catch(IOException e) {
	e.printStackTrace();
	throw new GameException ("file not found");
	}catch(ClassNotFoundException e) {
	e.printStackTrace();
	throw new GameException ("file not found");
	}catch(SQLException e) {
	e.printStackTrace();
	throw new GameException ("file not found");
	}
	 return conn;*/
	}
	

