package com.cg.gamespringmvc.service;

import java.util.List;

import com.cg.gamespringmvc.exception.GameException;
import com.cg.gamespringmvc.pojo.Day;
import com.cg.gamespringmvc.pojo.Game;
public interface GameService {
	public Game addGame(Game game);
	public List<Game> searchByName(String name) throws GameException ;
	public List<Game> searchByCategory(String category) ;
	
}
