package com.cg.gamespringmvc.controller;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.gamespringmvc.exception.GameException;
import com.cg.gamespringmvc.pojo.Day;
import com.cg.gamespringmvc.pojo.Game;
import com.cg.gamespringmvc.service.DayService;
import com.cg.gamespringmvc.service.GameService;

/** @Author Nikhitha
 * Written on21-05-2019
 * last Modified 22-05-2019
 **/
@Controller
public class MyController {
	@Autowired
	GameService gameService;
	/*@Autowired
	DayService dayService;*/
	Game ga;
	
	
	@GetMapping("login")
	public String loginPage() {
		return "listPage";
	}
	//-----------------------------------------------------------------//
	/** @Author Nikhitha
	 * Written on21-05-2019
	 * last Modified 22-05-2019
	 * @ModelAttribute game
	 * @return games 
	 * it will add game and day data**/
	//----------------------------------------------------------------//
	@GetMapping("addGamePage")
	public ModelAndView getAddProduct(@ModelAttribute("game") Game game/*,Map<String,Object> map*/)
	{
		List<String> listOfCategory=new ArrayList<>();
		listOfCategory.add("indoor");
		listOfCategory.add("outdoor");
		//	map.put(cato,listOfCategory);
		return new ModelAndView("addGame","key",listOfCategory);
		
	}
	/*Adding game details by entering name and category*/
	@PostMapping("addGame")
	public ModelAndView addGamePage(@ModelAttribute("game") Game game) {
		this.ga=game;
		return new ModelAndView("addDay");
	}
	@PostMapping("addDay")
	public ModelAndView addDay(@RequestParam("id") int id,@RequestParam("date")  @DateTimeFormat(pattern = "yyyy-MM-dd")Date date) throws GameException
	{
		System.out.println("hieeee");
		Day d=new Day();
		//d.setDate(date);
		d.setId(id);
		d.setDate(date);
		List<Day> daysList=new ArrayList<Day>();
		daysList.add(d);
		Game game=new Game();
		game.setId(ga.getId());
		game.setName(ga.getName());
		game.setCategory(ga.getCategory());
		//game.setDays(ga.getDays());
		game.setDays(daysList);
		//d.setGame(game);
		System.out.println(game);
		Game gameOne=gameService.addGame(game);
		//Day dayOne=dayService.addDay(d);
		System.out.println(gameOne);
		return new  ModelAndView("success","key",gameOne);
	}
	
	//-------------------------------------------------------------------//
	/** @Author Nikhitha
	 * Written on21-05-2019
	 * last Modified 22-05-2019
	 * @ModelAttribute game
	 * @Exception com.cg.gamespringmvc.exception
	 * @return games 
	 * It will game data by using game name **/
	//----------------------------------------------------------------------//
	/*@GetMapping("searchGameNamePage")
	public  ModelAndView getSearch(@ModelAttribute("game") Game game) {
		return new ModelAndView ("searchGameName");
	}
	@PostMapping("searchGameName")
	public ModelAndView searchGame(@ModelAttribute("game") Game game) throws GameException {
		System.out.println(game);
		List<Game> games=gameService.searchByName(game.getName());
		System.out.println("hiee"+games);
		return new ModelAndView("searchGameData","key",games);
	}
	*/
	
	
	@GetMapping("searchGameNamePage")
	public ModelAndView searchGameNamePage(@ModelAttribute("game") Game game) {
		return new ModelAndView("searchGameName");
	}
	@PostMapping("searchGameName")
	public ModelAndView searchGameName(@RequestParam("name") String name) throws GameException{
		List<Game> games=null;
		//Game game=new Game();
		System.out.println(name);
			games = gameService.searchByName(name);
			System.out.println("hiee in name"+games);	
			
			return new ModelAndView("searchGameData","key",games);		
	}
	//--------------------------------------------------------------------//
	/** @Author Nikhitha
	 * Written on21-05-2019
	 * last Modified 22-05-2019
	 * @ModelAttribute game
	 * @Exception com.cg.gamespringmvc.exception
	 * @return games 
	 * It will search game data by using game category **/
	//------------------------------------------------------------------//
	/*searching the game details by using game category*/
	@GetMapping("searchGameCategoryPage")
	public ModelAndView searchGameCategoryPage(@ModelAttribute("game") Game game) {
		return new ModelAndView("searchGameCategory");
	}
	@PostMapping("searchGameCategory")
	public ModelAndView searchGameCategory(@RequestParam("category") String category) {
		System.out.println(category);
		List<Game> games=gameService.searchByCategory(category);
		System.out.println("hiee in category"+games);
		return new ModelAndView("searchGameCategoryData","key",games);
	}
	
	
	/*@GetMapping("searchGameIdPage")
	public  ModelAndView getSearch(@ModelAttribute("game") Day day) {
		return new ModelAndView("searchGameById");
	}
	@PostMapping("searchGameById")
	public ModelAndView searchTrainee(@ModelAttribute("train") Day day) {
		System.out.println(day);
		Day days=gameService.searchById(day.getId());
		System.out.println("hiee"+days);
		return new ModelAndView("success","key",days);
	}
	*/
}
