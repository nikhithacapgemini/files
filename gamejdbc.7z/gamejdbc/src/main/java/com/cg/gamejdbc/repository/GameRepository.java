package com.cg.gamejdbc.repository;

import java.util.List;

import com.cg.gamejdbc.exceptions.GameException;
import com.cg.gamejdbc.pojo.Game;

public interface GameRepository {
	public List<Game> findByName(String Name) throws GameException;
	public List<Game> findByCategory(String Category) throws GameException;
	public Game saveGame(Game game) throws GameException;
	

}
