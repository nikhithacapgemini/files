package com.cg.gamespringmvc.repository;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.cg.gamespringmvc.pojo.Day;
import com.cg.gamespringmvc.pojo.Game;
@Repository
public class GameRepositoryImpl implements GameRepository{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	/** @Author Nikhitha
	 * Written on21-05-2019
	 * last Modified 22-05-2019
	 * @return game 
	 * It will save() data and return game **/
	public Game saveGame(Game game) {
		Game gOne;
		gOne=getGame(game.getId());
		gOne=getGame(game.getName());
		if(gOne==null) {
			entityManager.persist(game);
			entityManager.flush();
			return game;
		}
		else {
			Day day=new Day();
			day.setId(game.getDays().get(0).getId());
			day.setDate(game.getDays().get(0).getDate());
			day.setGame(gOne);
			entityManager.persist(day);
			entityManager.flush();
			
		}
		return game;
		
	}
		/*System.out.println(game);
		entityManager.persist(game);
		entityManager.flush();
		return game;
		Game gOne=getGame(game.getName());
		if(gOne==null) {
		entityManager.persist(game);
		entityManager.flush();
		}else {
			Day d=new Day();
			d.setGame(game.getDays().get(0).getGame());
			//d.setId(game.getDays().get(0).getId());
			d.setGame(gOne);
			entityManager.persist(game);
			entityManager.flush();		
		}
		return game;*/
	
	/** @Author Nikhitha
	 * Written on21-05-2019
	 * last Modified 22-05-2019
	 * @return List<Game> 
	 * It will find game data by using game name **/
	@Override
	public List<Game> findByName(String name)  {
		// TODO Auto-generated method stub	
		System.out.println("in search name");
		List<Game> gameOne=null;
		/*Query query1=entityManager.createQuery("Select name FROM Game");
		query1.setParameter(1,name);
		gameOne=query1.getResultList();*/
		
		Query query=entityManager.createQuery("FROM Game where name=:name");
		query.setParameter("name",name);
		gameOne=query.getResultList();
		System.out.println("in ----"+gameOne);
		return gameOne;
	}
	/** @Author Nikhitha
	 * Written on 21-05-2019
	 * last Modified 22-05-2019
	 * @return List<Game> 
	 * It will find game data by using game category **/
	@Override
	public List<Game> findByCategory(String category) {
		Query query=entityManager.createQuery("FROM Game where category=:category");
		query.setParameter("category",category);
		List<Game> gameOne=query.getResultList();
		return gameOne;
	}
	public Game getGame(Integer id) {
		// TODO Auto-generated method stub
				Game game=null;
		try {
			Query query=entityManager.createQuery("FROM Game where id=:id");
			query.setParameter("id",id);
			game=(Game) query.getSingleResult();
			}
			catch(NoResultException ex) {
				System.out.println("no id found");
			}
		return game;
	}
	public Game getGame(String name) {
		// TODO Auto-generated method stub
				Game game=null;
		try {
			Query query=entityManager.createQuery("FROM Game where name=:name");
			query.setParameter("name",name);
			game=(Game) query.getSingleResult();
			}
			catch(NoResultException ex) {
				System.out.println("no id found");
			}
		return game;
	}
	
	}


