package com.cg.gamee.service;

import java.util.Date;
import java.util.List;

import com.cg.gamee.exceptions.GameException;
import com.cg.gamee.pojo.Day;
import com.cg.gamee.pojo.Game;
import com.cg.gamee.repository.GameRepositoryImplementation;
import com.cg.gamee.repository.GameRepository;
public class GameServiceImplementation implements GameService
{
	GameRepository repositoryGame;
	public GameServiceImplementation() {
		repositoryGame=new GameRepositoryImplementation();
	}
	public Game addGame(Game game) {
		repositoryGame.saveGame(game);
		return game;
	}
	public List<Game> searchByName(String name) throws GameException {
		return repositoryGame.findByName(name);
		
	}
	public List<Game> searchByCategory(String category) throws GameException {
		return repositoryGame.findByCategory(category);
	}
	
}