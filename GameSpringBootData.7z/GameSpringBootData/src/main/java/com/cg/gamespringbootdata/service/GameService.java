package com.cg.gamespringbootdata.service;

import java.util.List;

import com.cg.gamespringbootdata.dto.Day;
import com.cg.gamespringbootdata.dto.Game;
import com.cg.gamespringbootdata.exception.GameException;

public interface GameService {
	public Game addGame(Game game) throws GameException;
	public Game searchByName(String name) throws GameException;
	public List<Game> searchByCategory(String category) throws GameException;
	
}
