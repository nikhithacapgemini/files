package com.cg.gamejpa.service;

import java.util.Date;
import java.util.List;

import com.cg.gamejpa.exceptions.GameException;
import com.cg.gamejpa.pojo.Day;
import com.cg.gamejpa.pojo.Game;
public interface DayService {
	public Day addDay(Day day) ;
	public List<Game> searchByDate(Date date) throws GameException ;
}
