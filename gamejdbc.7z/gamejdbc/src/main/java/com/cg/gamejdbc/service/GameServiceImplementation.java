package com.cg.gamejdbc.service;

import java.util.List;

import com.cg.gamejdbc.exceptions.GameException;
import com.cg.gamejdbc.pojo.Game;
import com.cg.gamejdbc.repository.GameRepository;
import com.cg.gamejdbc.repository.GameRepositoryImplementation;

public class GameServiceImplementation implements GameService{
	GameRepository repositoryGame;
	public GameServiceImplementation() {
		repositoryGame=new GameRepositoryImplementation();
	}
	public Game addGame(Game game) throws GameException {
		repositoryGame.saveGame(game);
		return game;
	}
	public List<Game> searchByName(String name) throws GameException {
		return repositoryGame.findByName(name);
		
	}
	public List<Game> searchByCategory(String category) throws GameException {
		return repositoryGame.findByCategory(category);
	}

}
