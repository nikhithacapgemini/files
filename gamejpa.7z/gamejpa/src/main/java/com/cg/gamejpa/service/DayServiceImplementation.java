package com.cg.gamejpa.service;

import java.util.Date;
import java.util.List;

import com.cg.gamejpa.exceptions.GameException;
import com.cg.gamejpa.pojo.Day;
import com.cg.gamejpa.pojo.Game;
import com.cg.gamejpa.repository.DayRepository;
import com.cg.gamejpa.repository.DayrepositoryImplementation;

public class DayServiceImplementation implements DayService{
	DayRepository dayrepository;
	public DayServiceImplementation() {
		dayrepository=new DayrepositoryImplementation();
	}

	public Day addDay(Day day) {
		dayrepository.save(day);
		return day;
	}

	public List<Game> searchByDate(Date date) throws GameException {
		List<Game> listSearch=dayrepository.findByDate(date);
		if(listSearch.isEmpty())
			throw new GameException("date not found");
		return listSearch;
	}

}
