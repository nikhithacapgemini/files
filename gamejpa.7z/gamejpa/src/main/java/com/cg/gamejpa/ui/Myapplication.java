package com.cg.gamejpa.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.gamejpa.exceptions.GameException;
import com.cg.gamejpa.pojo.Day;
import com.cg.gamejpa.pojo.Game;
import com.cg.gamejpa.service.DayService;
import com.cg.gamejpa.service.DayServiceImplementation;
import com.cg.gamejpa.service.GameService;
import com.cg.gamejpa.service.GameServiceImplementation;

public class Myapplication {
	static GameService serviceGame;
	static DayService serviceDay;
	public static void main(String[] args) throws GameException, ParseException 
	{
		serviceGame=new GameServiceImplementation();
		serviceDay=new DayServiceImplementation();
		Scanner scr=new Scanner(System.in);
		int choice=0;
		do {
			printDetails();
			System.out.println("Enter your choice");
			choice=scr.nextInt();
			switch(choice){

			case 1:
				Game game=new Game();
				System.out.println("Enter name of the game");
				String gameName=scr.next();
				System.out.println("enter game category");
				String gameCategory=scr.next();
				game.setName(gameName);
				game.setCategory(gameCategory);
				System.out.println(game);
				serviceGame.addGame(game);	
				break;

			case 2:
				
				System.out.println("enter the date");
				String addDate1=scr.next();
				SimpleDateFormat sdf3 = new SimpleDateFormat("dd-MM-yyyy");
				Date date4=null;
				try {
					date4 =  sdf3.parse(addDate1);
				} 
				catch (Exception e){
						System.out.println("Date " +  addDate1+ " is not valid according to " +((SimpleDateFormat) sdf3).toPattern() + " pattern.");
						break;
				}
				
				System.out.println("enter the name");
				String gname=scr.next();
				List<Game> games=serviceGame.searchByName(gname);
				System.out.println(games);
				Day day1=new Day();
				day1.setGame(games.get(0));
				List<Day> daysList=new ArrayList<Day>();
				day1.setDate(date4);
				daysList.add(day1);
				serviceDay.addDay(day1);
				System.out.println(daysList);
				
				
				break;
			
			case 3:
				System.out.println("Enter the game name to search");
				String gameNameToSearch=scr.next();
				List<Game> gameSearch=null;
				try {
						gameSearch=serviceGame.searchByName(gameNameToSearch);
						for (Game game2 : gameSearch) {
							System.out.println("game name : "+game2.getName() );
							System.out.println("game category : "+game2.getCategory());
						}
					}
				catch(GameException e) {
					System.err.println(e.getMessage());
				}
				break;

			case 4:	
				System.out.println("Enter the category name to search ");
				String gameCategoryToSearch=scr.next();
				List<Game> gameSearchTwo=null;
				try {
				gameSearchTwo=serviceGame.searchByCategory(gameCategoryToSearch);
				if(gameSearchTwo!=null) {
					for (Game game2 : gameSearchTwo) {
						System.out.println("game name : "+game2.getName() );
						System.out.println("game category : "+game2.getCategory());
					}
					}
				}
				catch(GameException e) {
					System.err.println(e.getMessage());
				}
				break;
			
			case 5: 
				System.out.println("enter the date");
				String searchDate=scr.next();
				SimpleDateFormat sdf4 = new SimpleDateFormat("dd-MM-yyyy");
				Date date5=null;
				try {
					date5 =  sdf4.parse(searchDate);
					} catch (Exception e1) {

					System.out.println("Date " +  searchDate+ " is not valid according to " +
					((SimpleDateFormat) sdf4).toPattern() + " pattern.");
					break;
				}
		
				try {
				List<Game> listSearch=serviceDay.searchByDate(date5);
				for (Game game2 : listSearch) 
				{
					System.out.println("game name : "+game2.getName());
					System.out.println(" category :"+game2.getCategory());
					
				}}
				catch(GameException e) {
					System.err.println(e.getMessage());
				}
				break;		
			}
				
		}while(choice!=6);
	
		}
	
	public static void printDetails()
	{
		System.out.println("1.Adding game   ");
		System.out.println("2.Adding date ");
		System.out.println("3.Search by game name");
		System.out.println("4.Search by category game : indoor/outdoor");
		System.out.println("5.Search by date");



	}



}
