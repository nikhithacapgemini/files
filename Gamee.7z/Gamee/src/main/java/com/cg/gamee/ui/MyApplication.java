package com.cg.gamee.ui;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.gamee.dbutil.DBUtilDay;
import com.cg.gamee.dbutil.DBUtilGame;
import com.cg.gamee.exceptions.GameException;
import com.cg.gamee.pojo.Day;
import com.cg.gamee.pojo.Game;
import com.cg.gamee.service.DayService;
import com.cg.gamee.service.DayServiceImplementation;
import com.cg.gamee.service.GameService;
import com.cg.gamee.service.GameServiceImplementation;


public class MyApplication
{	
	static GameService serviceGame;
	static DayService serviceDay;
	public static void main(String[] args) throws GameException 
	{
		serviceGame=new GameServiceImplementation();
		serviceDay=new DayServiceImplementation();
		Scanner scr=new Scanner(System.in);
		int choice=0;
		do {
			printDetails();
			System.out.println("Enter your choice");
			choice=scr.nextInt();
			switch(choice){

			case 1:	System.out.println("Enter name of the game");
			String gameName=scr.next();
			System.out.println("enter game category");
			String gameCategory=scr.next();
			System.out.println("Enter the game date ");
			DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
			String date =scr.next();
			Date date2=null;
			try {
				date2= format.parse(date);
			} 
			catch (Exception e) {
				System.out.println("Date " + date + " is not valid according to " +
						((SimpleDateFormat) format).toPattern() + " pattern.");
			}
			Game game=new Game();
			game.setName(gameName);
			game.setCategory(gameCategory);
			game.setDate(date2);
			serviceGame.addGame(game);
			break;

			case 2:System.out.println("Enter the date ");
			DateFormat format2 = new SimpleDateFormat("dd/MM/yyyy");
			String date3 =scr.next();
			Date date4=null;
			try {
				date4= format2.parse(date3);
			} 
			catch (Exception e) {
				System.out.println("Date " + date3 + " is not valid according to " +
						((SimpleDateFormat) format2).toPattern() + " pattern.");
			}
			List<Game> glist=new ArrayList<Game>();
			for(Game gameofdate:DBUtilGame.gamesList) {
				if(gameofdate.getDate().equals(date4))
				glist.add(gameofdate);

			}
			Day day=new Day(date4,glist);
			serviceDay.addDay(day);
			//System.out.println(serviceDay.addDay(day));
			break;
			case 3: System.out.println("Enter the game name to search");
			String gameNameToSearch=scr.next();
			try {
				List<Game> gameSearch=serviceGame.searchByName(gameNameToSearch);
				if(gameSearch!=null) {
					for (Game game2 : gameSearch) {
						System.out.println("game name : "+game2.getName() );
						System.out.println("game category : "+game2.getCategory());
						System.out.println("game date :"+game2.getDate());
					}
				}
			}catch(GameException e) {
				System.err.println(e.getMessage());
			}
			break;

			case 4:	System.out.println("Enter the category name to search ");
			String gameCategoryToSearch=scr.next();
			List<Game> gameSearchTwo=null;
			try {
				gameSearchTwo=serviceGame.searchByCategory(gameCategoryToSearch);
				//System.out.println("List of "+gameCategoryToSearch+ " games");
				for (Game game3 : gameSearchTwo) {
					System.out.println("List of "+game3.getCategory()+ " games");
					System.out.println(game3.getName() +" "+ game3.getDate());
				}}
			catch(GameException e) {
				System.err.println(e.getMessage());
			}
			break;
			
			case 5: System.out.println("Enter date to search DD/MM/YYYY");
			DateFormat format3 = new SimpleDateFormat("dd/MM/yyyy");
			String date5 =scr.next();
			Date dateToSearch=null;
			try {
				dateToSearch= format3.parse(date5);
			} catch (Exception e) {
				System.out.println("Date " + date5 + " is not valid according to " +
						((SimpleDateFormat) format3).toPattern() + " pattern.");
			}
			try {
				List<Day> dateSearch=serviceDay.searchByDate(dateToSearch);
			//	System.out.println(DBUtilDay.daysList);
				
			System.out.println(dateSearch);
				for (Day day2 :dateSearch) {
					System.out.println(" date : "+day2.getDate());
					System.out.println(" games : "+day2.getGame());
					}
				}catch(GameException e) {
					System.err.println(e.getMessage());
				}
			break;
			}			
		}while(choice!=6);
		scr.close();
	}
	public static void printDetails()
	{

		System.out.println("1.Adding game and date  ");
		System.out.println("2.Adding date ");
		System.out.println("3.Search by game name");
		System.out.println("4.Search by category game : indoor/outdoor");
		System.out.println("5.Search by date");



	}

}
