package com.cg.gamespringmvc.repository;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.cg.gamespringmvc.pojo.Day;
import com.cg.gamespringmvc.pojo.Game;
//@Repository
public class DayRepositoryImpl{
	
}
	

	/*@PersistenceContext
	EntityManager entityManager;
	@Override
	public Day save(Day day) {
		System.out.println("In save day()"+day);
		entityManager.persist(day);
		entityManager.flush();
		return day;
		Game game=new Game();
		Game gOne=getGame(game.getName());
		if(gOne==null) {
		entityManager.persist(day);
		entityManager.flush();
		}else {
			Day d=new Day();
			d.setDate(day.getDate());
			d.setGame(game.getDays().get(0).getGame());
			//d.setId(game.getDays().get(0).getId());
			d.setGame(gOne);
			System.out.println(day);
			entityManager.persist(day);
			entityManager.flush();		
		}
		return day;
		
		Game gOne=getGame(game.getName());
		if(gOne==null) {
		entityManager.persist(game);
		entityManager.flush();
		}else {
			Day d=new Day();
			d.setGame(game.getDays().get(0).getGame());
			//d.setId(game.getDays().get(0).getId());
			d.setGame(gOne);
			entityManager.persist(game);
			entityManager.flush();	
			return day;	
		}
		return game;
		// TODO Auto-generated method stub
		Query query=entityManager.createQuery("select g FROM Game g where g.name=:name");
		query.setParameter("name",day.getGame().getName());
		//entityManager.persist(day);
		List result=query.getResultList();
		if(result.size()==1) {
			entityManager.persist(day);
			Query queryOne=entityManager.createQuery("update Day set gamename=?1");
			queryOne.setParameter(1,query.getSingleResult());
			queryOne.executeUpdate();
		}
		else if(result.isEmpty()) {
			entityManager.persist(day);
		}
		return day;
	}

	@Override
	public List<Game> findByDate(Date date) {
		// TODO Auto-generated method stub
		return null;
	}
	public Game getGame(String name) {
		// TODO Auto-generated method stub
		Game game=null;
		
			Query query=entityManager.createQuery("FROM Game where name=:name");
			query.setParameter("name",name);
			game=(Game) query.getSingleResult();
		return null;
	}

}
*/