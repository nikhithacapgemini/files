package com.cg.ProductSpringBoot.services;
import java.util.List;
import com.cg.ProductSpringBoot.dto.Product;

public interface ProductService {
	public Product addProduct(Product pro);
	public List<Product> showAll();
	/*public Product searchById(int id);
	public void deleteById(int id);
	public Product updateById(Product product);*/
	public List<Product> searchByName(String name);
	public List<Product> searchByPrice(Double min,Double max);
}
