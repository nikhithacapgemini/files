package com.cg.gamespringmvc.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
/** @Author Nikhitha
 * Written on21-05-2019
 * last Modified 22-05-2019
 * It is @Entity
 **/
@Entity
//@Table(uniqueConstraints=@UniqueConstraint(columnNames="name"))
public class Game {
	@Id
	private Integer id;
	//@Column(unique=true)
	private String name;
	private String category;
	@OneToMany(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="gameid")
	private List<Day> days;
	public Game() {
		
	}
	public Game(Integer id, String name, String category, List<Day> days) {
		super();
		this.id = id;
		this.name = name;
		this.category = category;
		this.days = days;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public List<Day> getDays() {
		return days;
	}
	public void setDays(List<Day> days) {
		this.days = days;
	}
	@Override
	public String toString() {
		return "Game [id=" + id + ", name=" + name + ", category=" + category + ", days=" + days + "]";
	}
	
	
}
