package com.cg.gamespringcore.dbutil;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.cg.gamespringcore.exceptions.GameException;
import com.cg.gamespringcore.pojo.Game;
public class DBUtilGame {
	
	public static List<Game> gamesList=new ArrayList<Game>();
}
