package com.cg.gamespringcore.repository;

import java.util.Date;
import java.util.List;

import com.cg.gamespringcore.exceptions.GameException;
import com.cg.gamespringcore.pojo.Day;
import com.cg.gamespringcore.pojo.Game;

public interface DayRepository 
{
	public boolean save(Day day);
	public List<Game> findByDate(Date date) throws GameException;
}
