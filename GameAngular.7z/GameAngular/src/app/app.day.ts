
export class Day{
    id:number;
    date:Date;
}