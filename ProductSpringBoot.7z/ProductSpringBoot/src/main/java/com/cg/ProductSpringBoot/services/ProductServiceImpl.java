package com.cg.ProductSpringBoot.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ProductSpringBoot.dao.ProductDao;
import com.cg.ProductSpringBoot.dto.Product;
@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
	ProductDao productDao;
	@Override
	public Product addProduct(Product pro) {
		// TODO Auto-generated method stub
		return productDao.save(pro);
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return productDao.findAll();
	}
	public List<Product> searchByName(String name){
		
		return productDao.findByName(name);
		
	}

	@Override
	public List<Product> searchByPrice(Double min,Double max) {
		// TODO Auto-generated method stub
		return productDao.findByPriceBetween(min, max);
	}

	/*@Override
	public Product searchById(int id) {
		// TODO Auto-generated method stub
		return productDao.findById(id);
	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		 productDao.deleteById(id);
	}

	@Override
	public Product updateById(Product product) {
		// TODO Auto-generated method stub
		return productDao.updateById(product);
	}

	@Override
	public List<Product> searchByName(String name) {
		// TODO Auto-generated method stub
		return productDao.findByName(name);
	}
*/
}
