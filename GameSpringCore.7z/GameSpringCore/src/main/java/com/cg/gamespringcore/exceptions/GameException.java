package com.cg.gamespringcore.exceptions;

import com.cg.gamespringcore.ui.MyApplication;

public class GameException extends Exception
{

	public GameException() {
		super();
		//System.out.println(":not found");
	}

	public GameException(String string) {
		super(string);
		// TODO Auto-generated constructor stub
		//System.out.println("not found");
	}

	
}
