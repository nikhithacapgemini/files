package com.cg.gamejdbc.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;

import com.cg.gamejdbc.dbutil.DBUtil;
import com.cg.gamejdbc.exceptions.GameException;
import com.cg.gamejdbc.pojo.Day;
import com.cg.gamejdbc.pojo.Game;

public class DayRepositoryImplementation implements DayRepository{
	
	//adding the day 
	public Day save(Day day) throws GameException {
		Connection conn=null;
		PreparedStatement pstm=null;
		ResultSet result=null;
		
		try {
		conn=DBUtil.getConnection();
		}catch(GameException e) {
		e.printStackTrace();
		}
	//	System.out.println(day);
		String query="insert into day(date,gname) values(?,?)";
		try {
				java.sql.Date myDate=convertUtilToSql(day.getDate());
				pstm=conn.prepareStatement(query);
				pstm.setDate( 1,myDate);
				pstm.setString(2,day.getGames().get(0).getName());
				int res=pstm.executeUpdate();
				if(res>0) {
					System.err.println("data entered");
				}
		}
		catch(SQLException e) 
		{}
		finally {
		try {
			pstm.close();
			conn.close();
		} catch (SQLException e)
		{
			throw new GameException("close all the connections");
		}
	}
		 return day;
	}
	//finding the game details by using date
	public List<Game> findByDate(java.util.Date date) throws GameException {
		Connection conn=DBUtil.getConnection();
		PreparedStatement pstm=null;
		ResultSet result=null;
		List<Game> listByGame=null;
		try {
			String query="select g.name,g.category,d.date from game g right outer join day d on g.name=d.gname where d.date=?";
			java.sql.Date dateMy=convertUtilToSql(date);
			System.out.println(dateMy);
			listByGame=new ArrayList<Game>();
			pstm=conn.prepareStatement(query);
			pstm.setDate(1,dateMy);
			result=pstm.executeQuery();
			while(result.next()) {
				Game game=new Game();
				Day day=new Day();
				game.setName(result.getString(1));
				game.setCategory(result.getString(2));
				day.setDate(result.getDate(3));
				listByGame.add(game);
				}
			}
			catch (SQLException e)
			{
				throw new GameException("wrong in query");
			}
			finally {
			try {
				pstm.close();
				conn.close();
				
			} catch (SQLException e) {
				throw new GameException("close the connections");
			}
		}
		if(listByGame.isEmpty())
			throw new GameException("Given date not found ");
		return listByGame;

	}
	private static java.sql.Date convertUtilToSql(java.util.Date uDate) {
		java.sql.Date sDate = new java.sql.Date(uDate.getTime());
		return sDate;
	}
}