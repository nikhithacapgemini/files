package com.cg.gamespringmvc.pojo;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.format.annotation.DateTimeFormat;
/** @Author Nikhitha
 * Written on21-05-2019
 * last Modified 22-05-2019
 * It is @Entity
 **/
@Entity
@Table(name="day")
public class Day {
	@Id
	private Integer id;
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date date;
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="gameid")
	private Game game;
	public Day() {
		
	}
	
	
	public Day(Integer id, Date date, Game game) {
		super();
		this.id = id;
		this.date = date;
		this.game = game;
	}


	public Day(Date date, Game game) {
		super();
		this.date = date;
		this.game = game;
	}

	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Game getGame() {
		return game;
	}
	public void setGame(Game game) {
		this.game = game;
	}
	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	@Override
	public String toString() {
		return "Day [id=" + id + ", date=" + date + ", game=" + game + "]";
	}

		
	
}
