package com.cg.gamespringcore.pojo;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Component("game")
@Scope(value="prototype")
public class Game {
	private String name;
	private String category;
	public Game() {
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Game(String name, String category) {
		super();
		this.name = name;
		this.category = category;
	}
	@Override
	public String toString() {
		return "Game [name=" + name + ", category=" + category + "]";
	}
	
}