package com.cg.gamee.pojo;


import java.util.Date;
import java.util.List;
public class Day 
{
	private Date date;
	private List<Game> games;
	public Day() {
		super();

	}
	public Day(Date date, List<Game> games) {
		super();
		this.date =date ;
		this.games = games;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public List<Game> getGame() {
		return games;
	}
	public void setGame(Game game) {
		this.games =games;
	}
	@Override
	public String toString() {
		return "Day [date=" + date + ", game=" + games + "]";
	}
	
}
