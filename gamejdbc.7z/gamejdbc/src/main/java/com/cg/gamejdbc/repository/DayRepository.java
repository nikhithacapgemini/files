package com.cg.gamejdbc.repository;

import java.util.Date;
import java.util.List;
import com.cg.gamejdbc.exceptions.GameException;
import com.cg.gamejdbc.pojo.Day;
import com.cg.gamejdbc.pojo.Game;

public interface DayRepository {
	public Day save(Day day) throws GameException;
	public List<Game> findByDate(Date date) throws GameException;

}
