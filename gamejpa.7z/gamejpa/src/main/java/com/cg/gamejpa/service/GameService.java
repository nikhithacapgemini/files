package com.cg.gamejpa.service;

import java.util.List;

import com.cg.gamejpa.exceptions.GameException;
import com.cg.gamejpa.pojo.Game;
public interface GameService {
	public Game addGame(Game game);
	public List<Game> searchByName(String name) throws GameException ;
	public List<Game> searchByCategory(String category) throws GameException ;
}
