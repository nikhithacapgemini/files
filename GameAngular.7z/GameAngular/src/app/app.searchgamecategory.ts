import {Component} from '@angular/core';
import {GameService} from './app.gameservice';
import {Game} from './app.game';
@Component({
    selector:'searchcategory-game',
    templateUrl:'app.searchgamecategory.html',
})

export class SearchGameCategory{
    constructor(private gameservice:GameService){

    }
    games:Game;
    model:any={};
    name:string;
    p: number = 1;
    searchGameCategory(){
        this.gameservice.searchAllGameCategory(this.name).subscribe((data:Game)=>this.games=data);
    }

}