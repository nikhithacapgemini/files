package com.cg.gamespringmvc.repository;

import java.util.List;

import com.cg.gamespringmvc.exception.GameException;
import com.cg.gamespringmvc.pojo.Day;
import com.cg.gamespringmvc.pojo.Game;
public interface GameRepository {
	public List<Game> findByName(String Name) throws GameException ;
	public List<Game> findByCategory(String Category);
	public Game saveGame(Game game) ;
	
}
