package com.cg.gamejpa.repository;

import java.util.Date;
import java.util.List;

import com.cg.gamejpa.exceptions.GameException;
import com.cg.gamejpa.pojo.Day;
import com.cg.gamejpa.pojo.Game;


public interface DayRepository 
{
	public Day save(Day day);
	public List<Game> findByDate(Date date) throws GameException ;
}
