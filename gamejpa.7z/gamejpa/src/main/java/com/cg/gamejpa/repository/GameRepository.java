package com.cg.gamejpa.repository;

import java.util.List;

import com.cg.gamejpa.exceptions.GameException;
import com.cg.gamejpa.pojo.Game;

public interface GameRepository {
	public List<Game> findByName(String Name) throws GameException;
	public List<Game> findByCategory(String Category) throws GameException;
	public Game saveGame(Game game) ;
	

}
