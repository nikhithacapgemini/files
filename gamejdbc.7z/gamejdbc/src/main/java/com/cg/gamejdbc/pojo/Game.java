package com.cg.gamejdbc.pojo;

import java.util.Date;

public class Game {
	private String name;
	private String category;
	//private Date date;
	/*public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}*/

	public Game() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}
	public void setName(String Name) {
		this.name = Name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

	public Game(String name, String category) {
		super();
		this.name = name;
		this.category = category;
	}

	@Override
	public String toString() {
		return "Game [name=" + name + ", category=" + category + "]";
	}
	
	

	/*public Game(String name, String category, Date date) {
		super();
		this.name = name;
		this.category = category;
		this.date = date;
	}

	@Override
	public String toString() {
		return "Game [name=" + name + ", category=" + category + ", date=" + date + "]";
	}
*/
	


	
}
