package com.cg.demoonespringcore.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.demoonespringcore.dto.Item;
import com.cg.demoonespringcore.dto.Product;

public class MyTest {
	public static void main(String[] args) {
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		Product p=(Product) app.getBean("prod");
		p.getAllData();
	}
}
