import {Component} from '@angular/core';
import {Game} from './app.game';
import {Day} from './app.day';
import {GameService} from './app.gameservice';
@Component({
    selector:'searchname-game',
    templateUrl:'app.searchgamename.html',
})

export class SearchGameName{
    constructor(private gameservice:GameService){

    }
    games:any;
   model:any={};
    name:string;
    searchGameName(){
                this.gameservice.searchAllGameName(this.name).subscribe((data:any)=>this.games=data);
    }


/*games:any;
name:string;
 model:any={};
searchGameName(){
//this.gameservice.searchAllGameName(this.name).subscribe((data:any)=>console.log(data));
return this.gameservice.searchAllGameName(this.name).subscribe(data=>{this.games=Array.of(this.games);});

}*/
}