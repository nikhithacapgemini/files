package com.cg.gamejpa.service;

import java.util.List;

import com.cg.gamejpa.exceptions.GameException;
import com.cg.gamejpa.pojo.Game;
import com.cg.gamejpa.repository.GameRepository;
import com.cg.gamejpa.repository.GameRepositoryImplementation;

public class GameServiceImplementation implements GameService {
	
	GameRepository repositoryGame;
	public  GameServiceImplementation() {
		repositoryGame=new GameRepositoryImplementation();
	}
	public Game addGame(Game game) {
		repositoryGame.saveGame(game);
		return game;
	}

	public List <Game> searchByName(String name) throws GameException {
		List<Game> listSearch=repositoryGame.findByName(name);
		if(listSearch.isEmpty())
			throw new GameException("Game name not found");
		return listSearch;
	
	}

	public List<Game> searchByCategory(String category) throws GameException {
		List<Game> listSearch=repositoryGame.findByCategory(category);
		if(listSearch.isEmpty())
			throw new GameException("category not found");
		return listSearch;
	}

}
