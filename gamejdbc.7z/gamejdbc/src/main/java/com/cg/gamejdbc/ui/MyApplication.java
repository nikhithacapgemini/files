package com.cg.gamejdbc.ui;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.cg.gamejdbc.dbutil.DBUtil;
import com.cg.gamejdbc.exceptions.GameException;
import com.cg.gamejdbc.pojo.Day;
import com.cg.gamejdbc.pojo.Game;
import com.cg.gamejdbc.service.DayService;
import com.cg.gamejdbc.service.DayServiceImplementation;
import com.cg.gamejdbc.service.GameService;
import com.cg.gamejdbc.service.GameServiceImplementation;

public class MyApplication {
	static GameService serviceGame;
	static DayService serviceDay;
	public static void main(String[] args) throws GameException 
	{
		serviceGame=new GameServiceImplementation();
		serviceDay=new DayServiceImplementation();
		Scanner scr=new Scanner(System.in);
		int choice=0;
		do {
			printDetails();
			System.out.println("Enter your choice");
			choice=scr.nextInt();
			switch(choice){

			case 1:
				System.out.println("Enter name of the game");
				String gameName=scr.next();
				System.out.println("enter game category");
				String gameCategory=scr.next();
				Game game=new Game();
				game.setName(gameName);
				game.setCategory(gameCategory);
				serviceGame.addGame(game);
				break;

			case 2:
				System.out.println("enter the date");
				String addDate=scr.next();
				SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
				Date date2=null;
				try {
					date2 =  sdf2.parse(addDate);
				} catch (ParseException e1) {

					System.out.println("Date " +  addDate+ " is not valid according to " +
							((SimpleDateFormat) sdf2).toPattern() + " pattern.");
				}
				System.out.println("enter the name");
				String gname=scr.next();
				Game gameadd=new Game();
				gameadd.setName(gname);
				
				List<Game> mylist=new ArrayList<Game>();
				mylist.add(gameadd);
				Day day=new Day();
				day.setDate(date2);
				day.setGames(mylist);
				serviceDay.addDay(day);
				break;
			
			case 3:
				System.out.println("Enter the game name to search");
				String gameNameToSearch=scr.next();
				try {
						List<Game> gameSearch=serviceGame.searchByName(gameNameToSearch);
						if(gameSearch!=null) {
							for (Game game2 : gameSearch) {
								//System.out.println("game name : "+game2.getName() );
								//System.out.println("game category : "+game2.getCategory());
							}
						}
					}
				catch(GameException e) {
				System.err.println(e.getMessage());
				}
				break;

			case 4:	
				System.out.println("Enter the category name to search ");
				String gameCategoryToSearch=scr.next();
				try {
						List<Game> gameSearchTwo=null;
						System.out.println("List of "+gameCategoryToSearch+ " games");
						gameSearchTwo=serviceGame.searchByCategory(gameCategoryToSearch);
					}
				catch(GameException e) {
					System.err.println(e.getMessage());
				}
				break;
			
			case 5: 
				System.out.println("enter the date");
				String searchDate=scr.next();
				SimpleDateFormat sdf3 = new SimpleDateFormat("dd-MM-yyyy");
				Date date3=null;
				try {
					date3 =  sdf3.parse(searchDate);
				} catch (ParseException e1) {

					System.out.println("Date " +  searchDate+ " is not valid according to " +
					
							((SimpleDateFormat) sdf3).toPattern() + " pattern.");
				}
				try {
				List<Game> listSearch=serviceDay.searchByDate(date3);
				for (Game game2 : listSearch) 
					{
						System.out.println("game name : "+game2.getName());
						System.out.println(" category :"+game2.getCategory());
					
					}
				}
				catch(GameException e) {
					System.err.println(e.getMessage());
				}
						
				break;	
				}
	
		}while(choice!=6);
	
		}
	
	public static void printDetails()
	{
		System.out.println("1.Adding game and date  ");
		System.out.println("2.Adding date ");
		System.out.println("3.Search by game name");
		System.out.println("4.Search by category game : indoor/outdoor");
		System.out.println("5.Search by date");



	}


}
