package com.cg.gamespringcore.service;

import java.util.Date;
import java.util.List;

import com.cg.gamespringcore.exceptions.GameException;
import com.cg.gamespringcore.pojo.Day;
import com.cg.gamespringcore.pojo.Game;

public interface GameService 
{
	
	public Game addGame(Game game) throws GameException;
	public List<Game> searchByName(String name) throws GameException;
	public List<Game> searchByCategory(String category) throws GameException;
	
	
	
}
