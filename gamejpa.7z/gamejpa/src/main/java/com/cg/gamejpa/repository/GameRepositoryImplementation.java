package com.cg.gamejpa.repository;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;


import com.cg.gamejpa.dbutil.DbUtil;
import com.cg.gamejpa.exceptions.GameException;
import com.cg.gamejpa.pojo.Game;


public class GameRepositoryImplementation implements GameRepository 
{
	EntityManager em;
	public GameRepositoryImplementation(){
		//em=DbUtil.getConnection();
	}
	public Game saveGame(Game game) {
		try {
		em=DbUtil.getConnection();
		em.persist(game);
		em.getTransaction().commit();
		return game;
		}
		finally {
			if(em!=null)
				em.close();
			}
	}
	public List<Game> findByName(String name) throws GameException
	{
		try {
			em=DbUtil.getConnection();
			List<Game> gameOne=null;
			Query query=em.createQuery("select g FROM Game g where g.name=:name");
			query.setParameter("name",name);
			gameOne=query.getResultList();
			return gameOne;
			}
			catch(Exception e) {
				throw new GameException("game name not found");
			}
			finally {
			if(em!=null)
				em.close();
		}
				
	}
	public List<Game> findByCategory(String Category) throws GameException {
		try {
		em=DbUtil.getConnection();
		List<Game> gameList=null;
		Query query=em.createQuery("FROM Game where category=:category");
		query.setParameter("category",Category);
		gameList=query.getResultList();
		return gameList;
		}
		catch(Exception e) {
			throw new GameException("category not found");
		}
		finally {
			if(em!=null)
			em.close();
		}
	}

	
	}


