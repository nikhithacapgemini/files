import {Day} from './app.day';
export class Game{
  
    name:string;
    category:string;
    days:Day[];
}