package com.cg.gamejpa.query;

public interface QueryInterface 
{
	String queryfindname="FROM Game where name=:name";
	String queryfindcat="FROM Game where category=:category";
}
